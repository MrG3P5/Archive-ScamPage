<?php
error_reporting(0);
define('__LOCALFILE__', __FILE__); // __LOCALFILE__ = setup.php
define('HELLO', fopen(__FILE__, 'r')); // HELLO = opens the setup.php
fseek(HELLO, __COMPILER_HALT_OFFSET__); // Use HELLO to get the compiler

function replacedata($data) {
	$data = str_replace("#_^wkss|#","g",$data);
    $data = str_replace("#as|k#","n",$data);
    return $data;
}

function titidsss($data) {
    $data = replacedata($data);
        $data = str_replace("____%","z",$data);
    $data = str_replace("..]\^_",'R',$data);
    $data = str_replace(">^ol%%","I",$data);
    $data = str_replace("[..%__",'d',$data);
    return base64_decode($data);
}
print_r(titidsss(stream_get_contents(HELLO)));

/* 

halt compiler code here 

*/
__halt_compiler();
