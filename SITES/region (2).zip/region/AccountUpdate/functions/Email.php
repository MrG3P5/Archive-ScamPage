<?php

$Z118_EMAIL = "larrywach2007@outlook.com, miketaylor2456@gmail.com"; // PUT UR FUCKING E-MAIL BRO
?>
